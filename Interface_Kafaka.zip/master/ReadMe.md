﻿# Resources

## Contacts
* Sergej Dechant - sergej.dechant@boehringer-ingelheim.com
* Jan Kaiser - jan.kaiser@boehringer-ingelheim.com

## Overview
* https://developer.confluent.io/courses/apache-kafka-for-dotnet/delivery-guarantees-and-transactions/


## Schemas
* [BI Kafka Schema registry](https://schemaregistry-kafkanogxp-dev.apps.inh-dev.ocp.eu.boehringer.com/schemas/)
* [BI Kafka Schemas - Kafbat UI (requires permission - see instructions below)](https://kafbat-ui-kafkanogxp-dev.apps.inh-dev.ocp.eu.boehringer.com/ui/clusters/kafkanogxp-dev/schemas)
* [Introduction to Schema Registry in Kafka](https://medium.com/slalom-technology/introduction-to-schema-registry-in-kafka-915ccf06b902)
* [Why Avro for Kafka Data? (Schema format used by BI Kafka service)](https://www.confluent.io/blog/avro-kafka-data/)
* [Decoupling Systems with Apache Kafka, Schema Registry and Avro](https://www.confluent.io/blog/decoupling-systems-with-apache-kafka-schema-registry-and-avro/)
* [Avro C# example](https://github.com/confluentinc/confluent-kafka-dotnet/blob/master/examples/AvroSpecific/README.md)
* [Schema Registry API Reference | Confluent Documentation](https://docs.confluent.io/platform/current/schema-registry/develop/api.html#compatibility)

## View Kafka messages online
BI offers viewings Kafka messages in a [Kafbat](https://kafbat-ui-kafkanogxp-dev.apps.inh-dev.ocp.eu.boehringer.com/).  Access must be granted to access this tool.  Following the instructions below.
* [BI-IS-KAFKA-NONGXP - Backend GUI Access Management - MyServices](https://boehringer.service-now.com/esc?id=sc_cat_item&sys_id=2a8672ef47ed755832c7be3a516d4339)
* **Environment**: BI-IS-KAFKA.NONGXP(DEVELOPMENT)
* **Select account**: <your primary account>
* Select "Add Role (Request Access)
* **Access to be granted**: Admin  



